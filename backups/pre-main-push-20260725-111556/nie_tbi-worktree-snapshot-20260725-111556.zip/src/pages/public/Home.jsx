import SEOHead from '../../components/system/SEOHead';
import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Leaf, Zap, Cpu, Recycle, Globe, Wrench, ChevronDown, ChevronRight, Award, Star, TrendingUp, Users, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import StepCard from '../../components/StepCard';


const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const cardItem = {
  hidden: { opacity: 0, y: 30 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export default function Home() {
  const stepsRef = useRef(null);
  const stepsInView = useInView(stepsRef, { once: true, amount: 0.2 });

  return (
    <div>
      <SEOHead title="Home | NIETBI" description="Explore Home at NIE TBI. Learn more about our deep-tech incubation ecosystem." />
      {/* Hero Section */}
      <section style={{
        minHeight: '100dvh', background: '#060E24',
        paddingTop: 'calc(68px + var(--banner-h, 0px))',
        position: 'relative', overflow: 'hidden'
      }}>
        {/* Floating Orbs */}
        <motion.div animate={{ y: [0, -24, 0] }} transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
          style={{ position: 'absolute', top: '-10%', left: '-8%', width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle, rgba(46,95,217,0.35) 0%, transparent 70%)', filter: 'blur(60px)', pointerEvents: 'none' }} />
        <motion.div animate={{ y: [0, 20, 0] }} transition={{ duration: 11, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          style={{ position: 'absolute', bottom: '-15%', right: '-5%', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(245,130,31,0.3) 0%, transparent 70%)', filter: 'blur(70px)', pointerEvents: 'none' }} />
        <motion.div animate={{ y: [0, -16, 0] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          style={{ position: 'absolute', top: '35%', right: '30%', width: 360, height: 360, borderRadius: '50%', background: 'radial-gradient(circle, rgba(30,74,180,0.25) 0%, transparent 70%)', filter: 'blur(80px)', pointerEvents: 'none' }} />

        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '60px 24px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 60, position: 'relative', zIndex: 1, minHeight: 'calc(100vh - 200px)', alignItems: 'center' }}>
          
          <motion.div initial="hidden" animate="show" variants={{ hidden: {}, show: { transition: { staggerChildren: 0.13 } } }}>
            <motion.div variants={fadeUp} style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', backdropFilter: 'blur(12px)', padding: '6px 16px 6px 6px', borderRadius: 30, color: 'white', fontSize: 13, fontWeight: 600, marginBottom: 24 }}>
              <img src="/assets/gok-logo.png" alt="Govt. of Karnataka" style={{ height: 24, width: 'auto', objectFit: 'contain' }} />
              Supported by Govt. of Karnataka
            </motion.div>
            <motion.h1 variants={fadeUp} style={{ fontSize: 'clamp(36px, 4.5vw, 64px)', fontWeight: 800, lineHeight: 1.1, marginBottom: 24 }}>
              <span style={{ background: 'linear-gradient(135deg, #FFFFFF 0%, #A8C4FF 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Turning Ideas Into </span>
              <span style={{ background: 'linear-gradient(135deg, #F5821F 0%, #FF9A3C 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Impact.</span>
            </motion.h1>
            <motion.p variants={fadeUp} style={{ color: '#A0AECF', fontSize: 'clamp(15px, 1.4vw, 18px)', lineHeight: 1.7, marginBottom: 40, maxWidth: 520 }}>
              Empowering deep-tech startups in AgriTech, Clean Energy, Sustainable Technologies and AI & ML from Mysuru and beyond.
            </motion.p>
            <motion.div variants={fadeUp} style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              <Link to="/apply" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'linear-gradient(135deg, #F5821F 0%, #FF9A3C 100%)', color: '#fff', padding: '14px 32px', borderRadius: 8, textDecoration: 'none', fontWeight: 700, fontSize: 15, boxShadow: '0 4px 20px rgba(245,130,31,0.4)' }}>
                Apply Now →
              </Link>
              <a href="#stats-section" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'transparent', color: '#fff', padding: '14px 28px', borderRadius: 8, textDecoration: 'none', fontWeight: 600, fontSize: 15, border: '1px solid rgba(255,255,255,0.3)', backdropFilter: 'blur(8px)' }}>
                Learn More
              </a>
            </motion.div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }} 
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }} 
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }} 
            style={{ 
              position: 'relative', 
              maxWidth: 700, 
              margin: '0 auto', 
              width: '100%', 
              borderRadius: 24, 
              padding: 8, 
              background: 'rgba(255, 255, 255, 0.03)', 
              border: '1px solid rgba(255, 255, 255, 0.1)', 
              backdropFilter: 'blur(20px)',
              boxShadow: '0 20px 40px rgba(0, 0, 0, 0.4), 0 0 40px rgba(46, 95, 217, 0.2)'
            }}
          >
            <div style={{ borderRadius: 16, overflow: 'hidden', position: 'relative', aspectRatio: '16/9', background: '#000' }}>
              <video 
                src="/assets/hero-video.mp4" 
                autoPlay 
                muted 
                loop 
                playsInline 
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top right, rgba(6, 14, 36, 0.2), transparent)' }} />
            </div>
          </motion.div>
        </div>

        <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }} style={{ position: 'absolute', bottom: 32, left: '50%', transform: 'translateX(-50%)', color: 'rgba(255,255,255,0.4)', zIndex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 12, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Scroll to explore</span>
          <ChevronDown size={18} />
        </motion.div>
      </section>

      {/* Stats Section */}
      <section id="stats-section" style={{ background: '#FFFFFF', padding: '80px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 40, textAlign: 'center' }}>
             {[
               { num: 78, suffix: '+', label: 'Years of NIE Excellence' },
               { num: 6, suffix: '', label: 'Focus Innovation Sectors' },
               { num: 5, suffix: '+', label: 'Facilities & Resources' },
               { val: 'Tier 2', label: 'Region Impact Focus' }
             ].map((s, i) => (
               <motion.div key={i} variants={cardItem} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                 <div style={{ fontSize: 'clamp(36px, 4vw, 56px)', fontWeight: 800, color: 'var(--blue-dark)', borderBottom: '2px solid var(--orange)', paddingBottom: 8, marginBottom: 16 }}>
                   {s.num ? s.num : s.val}{s.suffix}
                 </div>
                 <div style={{ fontSize: 12, textTransform: 'uppercase', color: 'var(--gray-text)', fontWeight: 600, letterSpacing: '0.05em' }}>{s.label}</div>
               </motion.div>
             ))}
          </motion.div>

          {/* Supported & Recognised By Partners Bar */}
          <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} variants={fadeUp} style={{ marginTop: 60, paddingTop: 40, borderTop: '1px solid rgba(0,0,0,0.08)', textAlign: 'center' }}>
            <div style={{ color: 'var(--gray-text)', fontSize: 13, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 24 }}>
              Supported & Recognised by
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 40, flexWrap: 'wrap' }}>
              <img src="/assets/gok-logo.png" alt="Govt. of Karnataka" style={{ height: 48 }} />
              <img src="/assets/startup-karnataka.png" alt="Startup Karnataka" style={{ width: 80 }} />
              <img src="/assets/ktech-logo.jpeg" alt="K-Tech" style={{ width: 72, mixBlendMode: 'multiply' }} />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Focus Sectors */}
      <section style={{ background: 'var(--gray-light)', padding: '80px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} variants={fadeUp} style={{ textAlign: 'center', marginBottom: 48 }}>
            <h2 style={{ fontSize: 'clamp(26px, 3vw, 42px)', background: 'linear-gradient(135deg, #0D2B6E 0%, #2E5FD9 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 16 }}>Focus Innovation Sectors</h2>
            <p style={{ color: 'var(--gray-text)', fontSize: 16 }}>We specialize in deep-tech domains addressing global challenges.</p>
          </motion.div>
          <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }} className="grid-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
            {[
              { icon: Leaf, label: 'AgriTech', c: 'blue' },
              { icon: Zap, label: 'Clean Energy & EV', c: 'orange' },
              { icon: Cpu, label: 'AI & ML', c: 'blue' },
              { icon: Recycle, label: 'Waste to Wealth', c: 'orange' },
              { icon: Globe, label: 'Climate Tech', c: 'blue' },
              { icon: Wrench, label: 'Makerspace', c: 'orange' },
            ].map((sec, i) => (
              <motion.div key={i} variants={cardItem} whileHover={{ y: -8, boxShadow: '0 12px 32px rgba(13,43,110,0.1)' }} style={{ background: 'white', borderRadius: 16, border: '1px solid #E8ECF8', padding: '32px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', cursor: 'pointer' }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: sec.c === 'blue' ? 'rgba(46,95,217,0.12)' : 'rgba(245,130,31,0.18)', color: sec.c === 'blue' ? 'var(--blue-light)' : 'var(--orange)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
                  <sec.icon size={22} />
                </div>
                <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 600, fontSize: 14, color: 'var(--blue-dark)' }}>{sec.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── WHAT WE OFFER PREVIEW ── */}
      <section style={{ background: "var(--blue-dark)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            style={{ textAlign: "center", marginBottom: 48 }}
          >
            <h2 style={{
              fontFamily: "var(--font-heading)", fontWeight: 700,
              fontSize: "clamp(26px, 3vw, 42px)", margin: "0 0 12px",
              background: "linear-gradient(135deg, #FFFFFF 0%, #A8C4FF 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              What NIETBI Offers
            </h2>
            <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 16, fontFamily: "var(--font-body)" }}>
              World-class resources to take your startup from idea to market
            </p>
          </motion.div>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-100px" }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }}
            style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 24, marginBottom: 48 }}
          >
            {[
              { icon: <Wrench size={26} />, title: "Co-Working Space", desc: "Collaborative, fully equipped workspace for your team" },
              { icon: <Cpu size={26} />, title: "Expert Mentorship", desc: "Industry & academic mentor network for strategic guidance" },
              { icon: <Globe size={26} />, title: "Market Connect", desc: "Connections to customers, partners, and investor networks" },
            ].map((offer) => (
              <motion.div
                key={offer.title}
                variants={{ hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } } }}
                style={{
                  background: "rgba(255,255,255,0.06)",
                  borderRadius: 18, padding: 28,
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#fff",
                }}
              >
                <div style={{
                  width: 52, height: 52, borderRadius: 14,
                  background: "rgba(245,130,31,0.18)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "var(--orange)", marginBottom: 16,
                }}>
                  {offer.icon}
                </div>
                <h3 style={{ fontFamily: "var(--font-heading)", fontWeight: 700, fontSize: 20, margin: "0 0 8px", color: "#ffffff" }}>{offer.title}</h3>
                <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 16, lineHeight: 1.65, margin: 0, fontFamily: "var(--font-body)" }}>{offer.desc}</p>
              </motion.div>
            ))}
          </motion.div>
          <div style={{ textAlign: "center" }}>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }} style={{ display: "inline-block" }}>
              <Link to="/what-we-offer" style={{
                display: "inline-flex", alignItems: "center", gap: 8,
                background: "linear-gradient(135deg, #F5821F 0%, #FF9A3C 100%)",
                color: "#fff", padding: "14px 32px", borderRadius: 8,
                textDecoration: "none", fontWeight: 700, fontSize: 15,
                fontFamily: "var(--font-body)",
                boxShadow: "0 4px 20px rgba(245,130,31,0.4)",
              }}>
                View All Offerings <ChevronRight size={18} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── ACHIEVEMENTS & HIGHLIGHTS ── */}
      <section style={{ background: '#F4F6FB', padding: '80px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            style={{ textAlign: "center", marginBottom: 48 }}
          >
            <h2 style={{
              fontFamily: "var(--font-heading)", fontWeight: 700,
              fontSize: "clamp(26px, 3vw, 42px)", margin: "0 0 12px",
              background: "linear-gradient(135deg, #0D2B6E 0%, #2E5FD9 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              Our Achievements
            </h2>
            <p style={{ color: "var(--gray-text)", fontSize: 16, fontFamily: "var(--font-body)", maxWidth: 600, margin: '0 auto' }}>
              Celebrating the milestones that define our journey and the successes of our startups.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-100px" }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }}
            style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 32, marginBottom: 40 }}
          >
            {[
              { category: 'STARTUP', title: 'SportsKPI', desc: 'Leading analytics and live broadcasting platform for Indian sports — streaming and production services.', icon: <TrendingUp size={24} color="#3B82F6" /> },
              { category: 'AWARD', title: 'VS PRO TRADING', desc: 'Received "Innovative Startup of the Year 2024-25" from Karnataka Governor at Global India Business Forum.', icon: <Award size={24} color="#EAB308" /> },
              { category: 'HACKATHON', title: 'Smart India Hackathon', desc: 'Served as nodal center (2023-24) with direct interaction from PM Narendra Modi.', icon: <Cpu size={24} color="#10B981" /> }
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={{ hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } } }}
                whileHover={{ y: -8, boxShadow: '0 24px 48px rgba(13,43,110,0.12)' }}
                style={{
                  background: 'white',
                  borderRadius: 20,
                  border: '1px solid #E8ECF8',
                  padding: 32,
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'all 0.3s ease'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
                  <div style={{ padding: 10, background: '#F4F6FB', borderRadius: 12 }}>
                    {item.icon}
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', color: '#64748B' }}>{item.category}</span>
                </div>
                <h3 style={{ fontFamily: "var(--font-heading)", fontSize: 22, fontWeight: 800, color: '#0F172A', marginBottom: 16, lineHeight: 1.3, margin: 0 }}>{item.title}</h3>
                <p style={{ fontFamily: "var(--font-body)", color: '#475569', fontSize: 15, lineHeight: 1.6, flexGrow: 1, margin: 0, marginTop: 16 }}>{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>

          <div style={{ textAlign: "center" }}>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }} style={{ display: "inline-block" }}>
              <Link to="/achievements" style={{
                display: "inline-flex", alignItems: "center", gap: 8,
                background: "transparent", color: "var(--blue-dark)", padding: "14px 32px", borderRadius: 8,
                textDecoration: "none", fontWeight: 700, fontSize: 15, fontFamily: "var(--font-body)",
                border: "2px solid rgba(13,43,110,0.2)", transition: "border 0.3s"
              }}>
                View All Achievements <ChevronRight size={18} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── HOW TO APPLY ── */}
      <section style={{ background: "#ffffff", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            style={{ textAlign: "center", marginBottom: 56 }}
          >
            <h2 style={{
              fontFamily: "var(--font-heading)", fontWeight: 700,
              fontSize: "clamp(26px, 3vw, 42px)", margin: "0 0 12px",
              background: "linear-gradient(135deg, #0D2B6E 0%, #2E5FD9 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              How to Apply
            </h2>
            <p style={{ color: "var(--gray-text)", fontSize: 16, fontFamily: "var(--font-body)" }}>
              A simple four-step journey to join our incubator
            </p>
          </motion.div>
          <motion.div
            ref={stepsRef}
            initial="hidden"
            animate={stepsInView ? "show" : "hidden"}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.14 } } }}
            style={{ display: "flex", gap: 24, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", position: "relative" }}
            className="steps-row"
          >
            {[
              { step: 1, title: "Scan & Apply", desc: "Fill online application form" },
              { step: 2, title: "Screening", desc: "Expert panel reviews your application" },
              { step: 3, title: "Pitch & Interview", desc: "Present your idea to the selection committee" },
              { step: 4, title: "Onboarding", desc: "Join NIETBI & start your journey" },
            ].map((s, idx, arr) => (
              <React.Fragment key={s.step}>
                <motion.div
                  variants={{ hidden: { opacity: 0, x: -30 }, show: { opacity: 1, x: 0, transition: { duration: 0.55, ease: "easeOut" } } }}
                  style={{ flex: "1 1 180px", position: "relative" }}
                >
                  <StepCard number={s.step} title={s.title} description={s.desc} />
                </motion.div>
                {idx < arr.length - 1 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={stepsInView ? { opacity: 1, scale: 1, x: [0, 10, 0] } : { opacity: 0, scale: 0.8 }}
                    transition={stepsInView ? { 
                      opacity: { duration: 0.4, delay: 0.3 * idx },
                      scale: { duration: 0.4, delay: 0.3 * idx },
                      x: { duration: 1.5, repeat: Infinity, ease: "easeInOut" }
                    } : {}}
                    className="step-arrow"
                    style={{ color: 'var(--orange)', opacity: 0.6, flexShrink: 0 }}
                  >
                    <ChevronRight size={36} />
                  </motion.div>
                )}
              </React.Fragment>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Banner */}
      <section style={{ background: 'linear-gradient(135deg, #0D2B6E 0%, #1A3F9F 100%)', padding: '80px 24px', textAlign: 'center', color: 'white' }}>
        <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} variants={fadeUp}>
          <h2 style={{ fontSize: 'clamp(26px, 3vw, 42px)', color: 'white', marginBottom: 16 }}>Applications Are Now Open</h2>
          <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 18, marginBottom: 40, maxWidth: 600, margin: '0 auto 40px' }}>Join NIETBI and take your startup from idea to commercialization.</p>
          <Link to="/apply" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'linear-gradient(135deg, #F5821F 0%, #FF9A3C 100%)', color: '#fff', padding: '16px 36px', borderRadius: 8, textDecoration: 'none', fontWeight: 700, fontSize: 16, boxShadow: '0 4px 20px rgba(245,130,31,0.4)' }}>
            Apply for Incubation →
          </Link>
        </motion.div>
      </section>
      <style>{`
        @media (max-width: 640px) {
          .steps-row { flex-direction: column !important; align-items: center !important; }
          .step-arrow { display: none !important; }
        }
      `}</style>
    </div>
  );
}
